ROZLICZENIE BUDOWY — PROJEKT ANDROID

To jest projekt źródłowy aplikacji Android, a nie gotowy plik APK.

Funkcje:
- procent pracownika ustawiany suwakiem,
- pozostała kwota dzielona po połowie,
- nazwa i kwota budowy,
- historia zapisanych budów,
- otwieranie i usuwanie zapisów,
- eksport historii CSV,
- kalkulator działa lokalnie, bez połączenia z internetem.

Jak zbudować APK na Windows:
1. Zainstaluj Android Studio.
2. Rozpakuj ZIP.
3. W Android Studio wybierz Open i wskaż folder RozliczenieBudowyAndroid.
4. Poczekaj na synchronizację Gradle i instalację wymaganych komponentów Android SDK.
5. Wybierz Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK znajdziesz w app/build/outputs/apk/debug/app-debug.apk

Wymagania projektu:
- Android Gradle Plugin 8.7.3
- Gradle 8.9 lub nowszy zgodny z pluginem
- Android SDK Platform 35
- JDK 17 lub nowszy

Uwaga:
- Dane historii są zapisywane lokalnie w pamięci aplikacji (WebView localStorage).
- Odinstalowanie aplikacji lub wyczyszczenie jej danych może skasować historię.
- Projekt nie wymaga uprawnienia INTERNET.
